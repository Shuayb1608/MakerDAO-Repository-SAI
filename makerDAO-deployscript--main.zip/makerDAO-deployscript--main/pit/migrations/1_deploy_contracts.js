const GemPit = artifacts.require("GemPit");

module.exports = function(deployer) {

  deployer.deploy(GemPit);
};