const SaiTop = artifacts.require("SaiTop");

module.exports = function (deployer) {

  deployer.deploy(SaiTop,"0x0b0ea2EC571e836aeC8C3a0dee42B28CBB70f0e1","0xb74aaF6d1AeCd3550c330C74b71C7ad532a00039" );
};