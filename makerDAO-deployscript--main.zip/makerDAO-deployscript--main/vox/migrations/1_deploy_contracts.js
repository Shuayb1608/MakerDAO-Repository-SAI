const SaiVox = artifacts.require("SaiVox");

module.exports = function(deployer) {

  deployer.deploy(SaiVox,100000000000);
};