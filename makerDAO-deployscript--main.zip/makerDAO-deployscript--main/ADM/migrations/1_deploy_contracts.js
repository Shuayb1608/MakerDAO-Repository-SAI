const DSChief = artifacts.require("DSChief");

module.exports = function(deployer) {

  deployer.deploy(DSChief,"0x0904b6Df12C0Af99352C132FA12652fb695141F9","0x422aD99F0bf2852bE5666585fC75758c5BdD9577",5);
};
// IOU
// GoV