const DSGuardFactory = artifacts.require("DSGuardFactory");

module.exports = function(deployer) {

  deployer.deploy(DSGuardFactory);
};