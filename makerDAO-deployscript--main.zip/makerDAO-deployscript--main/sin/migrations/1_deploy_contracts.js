const DSToken = artifacts.require("DSToken");

module.exports = async function(deployer) {
const instance = await DSToken.deployed();
  deployer.deploy(DSToken,"&&", instance.address);
};