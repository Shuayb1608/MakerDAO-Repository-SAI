const Medianizer = artifacts.require("Medianizer");

module.exports = function(deployer) {

  deployer.deploy(Medianizer);
};