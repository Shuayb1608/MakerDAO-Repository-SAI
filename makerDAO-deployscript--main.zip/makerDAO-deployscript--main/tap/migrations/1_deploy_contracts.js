const SaiTap = artifacts.require("SaiTap");

module.exports = function (deployer) {

  deployer.deploy(SaiTap,"0x0b0ea2EC571e836aeC8C3a0dee42B28CBB70f0e1" );
};