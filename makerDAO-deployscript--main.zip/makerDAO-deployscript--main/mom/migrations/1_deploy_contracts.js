const SaiMom = artifacts.require("SaiMom");

module.exports = function (deployer) {

  deployer.deploy(SaiMom,"0x0b0ea2EC571e836aeC8C3a0dee42B28CBB70f0e1","0xb74aaF6d1AeCd3550c330C74b71C7ad532a00039","0x579819b56bA9e4F8015955992Cc3483cA72f694D");
};