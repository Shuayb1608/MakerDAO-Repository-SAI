# makerDAO-deployscript-
Deploying SAI contracts 

## 1-Deployed the GEM
### Constructor parameter:(no cunstructor patameters)
#### 0x47E317B16294B1b3B751091f82DE7cd17eeD2e0F
### Deployment Commands 
```
truffle compile
truffle deploy --network goerli
```

## 2-Deployed the Gov
### Constructor parameter:(TokenSymbol)
#### 0x0904b6Df12C0Af99352C132FA12652fb695141F9
### Deployment Commands 
```
truffle compile
truffle deploy --network goerli
```

## 3-Deployed the PIP
### Constructor parameter:(no cunstructor patameters)
#### 0xce481122681cDAFea6B755F187f320748b124BFb
### Deployment Commands 
```
truffle compile
truffle deploy --network goerli
```

## 4-Deployed the PEP
### Constructor parameter:(no cunstructor patameters)
#### 0xf0D79BD331cAd152B19FE0B400fD98F28406995A
### Deployment Commands 
```
truffle compile
truffle deploy --network goerli
```

## 5-Deployed the PIt
### Constructor parameter:(no cunstructor patameters)
#### 0xC23cb243db7d4188477bF23FEC9Ff00AD254C080
### Deployment Commands 
```
truffle compile
truffle deploy --network goerli
```

## 6-Deployed the IOU
#### Constructor parameter:(TokenSymbol)
#### 0x422aD99F0bf2852bE5666585fC75758c5BdD9577 
### Deployment Commands 
```
truffle compile
truffle deploy --network goerli
```

## 7-Deployed the ADM
### Constructor parameter:(Gov,IOU) //Contract address 
#### 0x0F86A77922128BEE9eA9970B39375974eD8Bc150
### Deployment Commands 
```
truffle compile
truffle deploy --network goerli
```

## 8-Deployed the SAI
### Constructor parameter:(TokenSymbol)
#### 0x548CD22d06fE1eA6C55b696F8918d415C0907445
### Deployment Commands 
```
truffle compile
truffle deploy --network goerli
```

## 9-Deployed the SIN
### Constructor parameter:(TokenSymbol)
#### 0x6dE63693Db3F442005e11A9f312774FDFdfa2604
### Deployment Commands 
```
truffle compile
truffle deploy --network goerli
```

## 10-Deployed the SKR
### Constructor parameter:(TokenSymbol) 
#### 0xF8c56144b2D45A77e1388F34A222De59c282eef9
### Deployment Commands 
```
truffle compile
truffle deploy --network goerli
```

## 11-Deployed the DAD
### Constructor parameter:(no cunstructor patameters)
#### 0xE730D1cbC5f0B130235D64F4b7bD42E2801B9816
### Deployment Commands 
```
truffle compile
truffle deploy --network goerli
```

## 12-Deployed the VOX
### Constructor parameter:(uint parameter)
#### 0x579819b56bA9e4F8015955992Cc3483cA72f694D
### Deployment Commands 
```
truffle compile
truffle deploy --network goerli
```

## 13-Deployed the TUB
### Constructor parameter:(sai,sin,skr,gem,gov,pip,pep,vox,pit) //Contract address
### 0x0b0ea2EC571e836aeC8C3a0dee42B28CBB70f0e1 
### Deployment Commands 
```
truffle compile
truffle deploy --network goerli
```

## 14-Deployed the TAP
### Constructor parameter:(tub) //Contract address
#### 0xb74aaF6d1AeCd3550c330C74b71C7ad532a00039
### Deployment Commands 
```
truffle compile
truffle deploy --network goerli
```

## 15-Deployed the TOP
### Constructor parameter:(tub,Tap) //Contract address
#### 0xBd1fb2D9c124c487cEbb0e7AC714c6565100Bbe2 
### Deployment Commands 
```
truffle compile
truffle deploy --network goerli
```

## 16-Deployed the MOM
### Constructor parameter:(tub,tap,vox) //Contract address
#### 0x9078B4B6E4C0e0EF8bF6aF6fBC4aBf28183fD8af
### Deployment Commands
```
truffle compile
truffle deploy --network goerli
```
